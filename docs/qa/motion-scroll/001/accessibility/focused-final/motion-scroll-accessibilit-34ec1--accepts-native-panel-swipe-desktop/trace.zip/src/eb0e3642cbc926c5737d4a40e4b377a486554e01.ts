import {expect, test, type Page} from "@playwright/test";
import en from "../../src/i18n/messages/en.json";
import ru from "../../src/i18n/messages/ru.json";
import sr from "../../src/i18n/messages/sr.json";

async function state(page: Page) {
  return page.evaluate(() => ({url: location.href, y: scrollY, root: document.documentElement.className, reduced: matchMedia("(prefers-reduced-motion: reduce)").matches, focus: document.activeElement?.outerHTML.slice(0, 300)}));
}

async function settled(page: Page) {
  await page.evaluate(() => new Promise<void>((resolve, reject) => {
    let last = scrollY, stable = 0, frames = 0;
    const tick = () => { stable = Math.abs(scrollY - last) < 0.5 ? stable + 1 : 0; last = scrollY; if (stable >= 12) resolve(); else if (++frames > 360) reject(new Error("scroll did not settle")); else requestAnimationFrame(tick); };
    requestAnimationFrame(tick);
  }));
}

for (const motion of ["no-preference", "reduce"] as const) {
  test(`${motion}: keyboard focus, skip and full route history`, async ({page}, info) => {
    const observations: unknown[] = [];
    await page.emulateMedia({reducedMotion: motion});
    await page.setViewportSize({width: 1440, height: 900});
    await page.goto("/en");
    if (motion === "reduce") await expect(page.locator("html")).not.toHaveClass(/\blenis\b/);
    else await expect(page.locator("html")).toHaveClass(/\blenis\b/);
    await page.keyboard.press("Tab");
    await expect(page.getByRole("link", {name: "Skip to content"})).toBeFocused();
    await page.keyboard.press("Enter");
    await expect(page).toHaveURL(/#main-content$/);
    await expect.poll(() => page.locator("#main-content").evaluate(el => Math.abs(el.getBoundingClientRect().top))).toBeLessThan(3);
    observations.push({step: "skip", ...(await state(page))});
    const target = page.locator("footer a[href]").last();
    await target.focus();
    await expect(target).toBeFocused();
    await expect.poll(() => target.evaluate(el => { const r = el.getBoundingClientRect(); return r.bottom > 0 && r.top < innerHeight; })).toBe(true);
    await settled(page);
    observations.push({step: "offscreen focus", ...(await state(page))});
    await page.goto("/en/about");
    await page.keyboard.press("End");
    await expect.poll(() => page.evaluate(() => Math.abs(document.documentElement.scrollHeight - innerHeight - scrollY))).toBeLessThan(2);
    await settled(page);
    await page.keyboard.press("Home");
    await expect.poll(() => page.evaluate(() => scrollY)).toBeLessThan(10);
    await settled(page);
    observations.push({step: "home settled", ...(await state(page))});
    await page.keyboard.press("PageDown");
    await expect.poll(() => page.evaluate(() => scrollY)).toBeGreaterThan(100);
    await settled(page);
    observations.push({step: "page down", ...(await state(page))});
    const link = page.getByRole("banner").getByRole("link", {name: "Contact", exact: true});
    await link.focus();
    await settled(page);
    const beforeRoute = await page.evaluate(() => scrollY);
    await link.click();
    await expect(page).toHaveURL(/\/en\/contact$/);
    observations.push({step: "contact", ...(await state(page))});
    await page.goBack();
    await expect(page).toHaveURL(/\/en\/about$/);
    await settled(page);
    await expect.poll(() => page.evaluate(() => scrollY)).toBeCloseTo(beforeRoute, 0);
    observations.push({step: "back", beforeRoute, ...(await state(page))});
    await page.goForward();
    await expect(page).toHaveURL(/\/en\/contact$/);
    await settled(page);
    observations.push({step: "forward", ...(await state(page))});
    const header = page.getByRole("banner");
    await header.getByRole("button", {name: /Language/}).click();
    await header.getByRole("link", {name: "Srpski", exact: true}).click();
    await expect(page).toHaveURL(/\/sr\/contact$/);
    await expect(page.locator("html")).toHaveAttribute("lang", "sr-Latn");
    observations.push({step: "locale", ...(await state(page))});
    await info.attach("focus-history.json", {body: JSON.stringify(observations, null, 2), contentType: "application/json"});
  });
}

for (const [locale, {Navigation: labels}] of Object.entries({en, ru, sr})) {
  for (const width of [360, 768, 1440]) {
    test(`${locale} ${width}: static chrome, controls and focus bounds`, async ({page}, info) => {
      await page.setViewportSize({width, height: 900});
      await page.emulateMedia({reducedMotion: "no-preference"});
      await page.goto(`/${locale}/about`);
      await expect(page.locator("html")).toHaveClass(/\blenis\b/);
      await page.evaluate(() => document.fonts.ready);
      const header = page.getByRole("banner");
      const control = width < 1000 ? header.locator('button[aria-haspopup="dialog"]') : header.getByRole("navigation", {name: labels.navigation});
      await expect(control).toBeVisible();
      if (width < 1000) {
        await control.focus();
        await expect(control).toBeFocused();
        await control.click();
        await expect(page.getByRole("dialog")).toBeVisible();
      }
      const scope = width < 1000 ? page.getByRole("dialog") : control;
      const metrics = await scope.locator("a:visible, button:visible").evaluateAll(elements => elements.map(el => {
        const r = el.getBoundingClientRect(), css = getComputedStyle(el);
        return {text: el.textContent?.trim(), x: r.x, y: r.y, width: r.width, height: r.height, scrollWidth: el.scrollWidth, clientWidth: el.clientWidth, color: css.color, font: css.fontFamily};
      }));
      expect(metrics.length).toBeGreaterThan(0);
      for (const r of metrics) {
        expect(r.width).toBeGreaterThan(0);
        expect(r.x).toBeGreaterThanOrEqual(-1);
        expect(r.x + r.width).toBeLessThanOrEqual(width + 1);
        expect(r.scrollWidth).toBeLessThanOrEqual(r.clientWidth + 1);
      }
      await info.attach("bounds.json", {body: JSON.stringify(metrics, null, 2), contentType: "application/json"});
      await page.screenshot({path: info.outputPath("chrome.png")});
      if (width < 1000) {
        await page.keyboard.press("Escape");
        await expect(control).toBeFocused();
      }
    });
  }
}

test("touch-emulated short menu accepts native panel swipe", async ({browser}, info) => {
  const context = await browser.newContext({baseURL: "http://127.0.0.1:3100", viewport: {width: 390, height: 300}, hasTouch: true, isMobile: true, reducedMotion: "no-preference"});
  const page = await context.newPage();
  await page.goto("/en");
  await page.getByRole("button", {name: "Open navigation"}).tap();
  const panel = page.getByRole("dialog");
  await expect(panel).toBeVisible();
  const box = (await panel.boundingBox())!;
  const session = await context.newCDPSession(page);
  const x = box.x + box.width / 2, y = Math.min(box.y + box.height - 30, 260);
  await session.send("Input.synthesizeScrollGesture", {x, y, yDistance: -180, gestureSourceType: "touch", speed: 600});
  await expect.poll(() => panel.evaluate(el => el.scrollTop)).toBeGreaterThan(0);
  await expect.poll(() => page.evaluate(() => scrollY)).toBe(0);
  await info.attach("touch.json", {body: JSON.stringify({panelScroll: await panel.evaluate(el => el.scrollTop), windowScroll: await page.evaluate(() => scrollY), box}, null, 2), contentType: "application/json"});
  await context.close();
});

test("current SSR and hydrated reduced and normal chrome at rest", async ({browser}, info) => {
  const samples = [];
  for (const mode of ["no-js", "reduce", "normal"] as const) {
    const context = await browser.newContext({baseURL: "http://127.0.0.1:3100", viewport: {width: 1440, height: 900}, javaScriptEnabled: mode !== "no-js", reducedMotion: mode === "reduce" ? "reduce" : "no-preference"});
    const page = await context.newPage();
    await page.goto("/en/about");
    await page.evaluate(() => document.fonts.ready);
    if (mode === "normal") await expect(page.locator("html")).toHaveClass(/\blenis\b/);
    const sample = await page.locator("header").evaluate(el => { const r = el.getBoundingClientRect(), c = getComputedStyle(el); return {x: r.x, y: r.y, width: r.width, height: r.height, color: c.color, font: c.fontFamily}; });
    samples.push({mode, ...sample});
    await page.screenshot({path: info.outputPath(`${mode}.png`)});
    await context.close();
  }
  expect(samples[1].height).toBe(samples[0].height);
  expect(samples[2].height).toBe(samples[0].height);
  await info.attach("render-comparison.json", {body: JSON.stringify(samples, null, 2), contentType: "application/json"});
});
