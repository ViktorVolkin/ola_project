import {expect, test} from "@playwright/test";

test("wheel smoothing and live reduced-motion fallback", async ({page}) => {
  await page.emulateMedia({reducedMotion: "no-preference"});
  await page.goto("/en");
  const root = page.locator("html");
  await expect(root).toHaveClass(/\blenis\b/);
  await page.mouse.move(500, 400);
  await page.mouse.wheel(0, 650);
  await expect.poll(() => page.evaluate(() => window.scrollY)).toBeGreaterThan(0);
  await page.emulateMedia({reducedMotion: "reduce"});
  await expect(root).not.toHaveClass(/\blenis\b/);
  const before = await page.evaluate(() => window.scrollY);
  await page.mouse.wheel(0, 500);
  await expect.poll(() => page.evaluate(() => window.scrollY)).toBeGreaterThan(before);
  await page.emulateMedia({reducedMotion: "no-preference"});
  await expect(root).toHaveClass(/\blenis\b/);
});

test("reduced motion from first load and native keyboard/hash navigation", async ({page}) => {
  await page.emulateMedia({reducedMotion: "reduce"});
  await page.goto("/en#main-content");
  await expect(page.locator("html")).not.toHaveClass(/\blenis\b/);
  await expect(page.locator("#main-content")).toBeVisible();
  await page.keyboard.press("End");
  await expect.poll(() => page.evaluate(() => Math.abs(document.documentElement.scrollHeight - innerHeight - scrollY))).toBeLessThan(2);
  await page.keyboard.press("Home");
  await expect.poll(() => page.evaluate(() => window.scrollY)).toBeLessThan(10);
  await page.keyboard.press("PageDown");
  await expect.poll(() => page.evaluate(() => window.scrollY)).toBeGreaterThan(100);
});

test("active Lenis interpolates a wheel across animation frames", async ({page}) => {
  await page.emulateMedia({reducedMotion: "no-preference"});
  await page.goto("/en");
  await expect(page.locator("html")).toHaveClass(/\blenis\b/);
  await page.mouse.move(300, 400);
  const samples = page.evaluate(() => new Promise<number[]>((resolve) => {
    const values: number[] = [];
    const frame = () => {
      values.push(window.scrollY);
      if (values.length < 60) requestAnimationFrame(frame);
      else resolve(values);
    };
    requestAnimationFrame(frame);
  }));
  await page.mouse.wheel(0, 650);
  const values = await samples;
  expect(new Set(values.filter((value) => value > 0)).size).toBeGreaterThan(3);
});

test("active motion retains native keyboard navigation", async ({page}) => {
  await page.emulateMedia({reducedMotion: "no-preference"});
  await page.goto("/en");
  await expect(page.locator("html")).toHaveClass(/\blenis\b/);
  await page.keyboard.press("End");
  await expect.poll(() => page.evaluate(() => Math.abs(document.documentElement.scrollHeight - innerHeight - scrollY))).toBeLessThan(2);
  await page.keyboard.press("Home");
  await expect.poll(() => page.evaluate(() => window.scrollY)).toBeLessThan(10);
  await page.keyboard.press("PageDown");
  await expect.poll(() => page.evaluate(() => window.scrollY)).toBeGreaterThan(100);
});

test("active motion skip link and browser history preserve native hashes", async ({page}) => {
  await page.emulateMedia({reducedMotion: "no-preference"});
  await page.goto("/en");
  await expect(page.locator("html")).toHaveClass(/\blenis\b/);
  await page.keyboard.press("Tab");
  await expect(page.getByRole("link", {name: "Skip to content"})).toBeFocused();
  await page.keyboard.press("Enter");
  await expect(page).toHaveURL(/#main-content$/);
  await expect.poll(() => page.locator("#main-content").evaluate((element) => Math.abs(element.getBoundingClientRect().top))).toBeLessThan(3);
  await page.goBack();
  await expect(page).toHaveURL(/\/en$/);
  await page.goForward();
  await expect(page).toHaveURL(/#main-content$/);
  await expect.poll(() => page.locator("#main-content").evaluate((element) => Math.abs(element.getBoundingClientRect().top))).toBeLessThan(3);
  await page.goto("/en#main-content");
  await expect(page.locator("html")).toHaveClass(/\blenis\b/);
  await expect.poll(() => page.locator("#main-content").evaluate((element) => Math.abs(element.getBoundingClientRect().top))).toBeLessThan(3);
});

test("short mobile panel scrolls while background remains locked", async ({page}) => {
  await page.setViewportSize({width: 390, height: 300});
  await page.emulateMedia({reducedMotion: "no-preference"});
  await page.goto("/en");
  await expect(page.locator("html")).toHaveClass(/\blenis\b/);
  await page.getByRole("button", {name: "Open navigation"}).click();
  const dialog = page.getByRole("dialog");
  await expect(dialog).toBeVisible();
  await expect(page.locator("html")).not.toHaveClass(/\blenis\b/);
  await page.mouse.move(4, 4);
  await page.mouse.wheel(0, 500);
  await page.waitForTimeout(300);
  expect(await page.evaluate(() => window.scrollY)).toBe(0);
  await dialog.hover({position: {x: 150, y: 100}});
  await page.mouse.wheel(0, 400);
  await expect.poll(() => dialog.evaluate((element) => element.scrollTop)).toBeGreaterThan(0);
  await page.keyboard.press("Escape");
  await expect(page.locator("html")).toHaveClass(/\blenis\b/);
});

test("mobile modal suspends Lenis and restores it on Escape", async ({page}) => {
  await page.setViewportSize({width: 390, height: 700});
  await page.emulateMedia({reducedMotion: "no-preference"});
  await page.goto("/en");
  const root = page.locator("html");
  await expect(root).toHaveClass(/\blenis\b/);
  const trigger = page.getByRole("button", {name: "Open navigation"});
  await trigger.click();
  await expect(page.getByRole("dialog")).toBeVisible();
  await expect(root).not.toHaveClass(/\blenis\b/);
  await page.keyboard.press("Escape");
  await expect(trigger).toBeFocused();
  await expect(root).toHaveClass(/\blenis\b/);
});
